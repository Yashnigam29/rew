import { Component, OnInit } from '@angular/core';
import { ProductserveService} from '../productserve.service'
import { Product } from '../product';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css'],
})
export class AddComponent implements OnInit {
  products: Product[]=[];
  product:Product=new Product();
  constructor(private ProductserveService:ProductserveService) { }

  ngOnInit() {
  }
add():void{
  var a=(document.getElementById("id") as HTMLInputElement).value;
  var b=(document.getElementById("name") as HTMLInputElement).value;
  var c=(document.getElementById("desc") as HTMLInputElement).value;
  var d=(document.getElementById("price") as HTMLInputElement).value;
   var regid=/^[0-9]+$/
   var regName=/^[A-Z][a-z]+$/
  if(a=="" || b==""|| c==""|| d==""){
    alert("all field are required kindly add all data");

  }
  else{
    if(a.match(regid) && d.match(regid) && b.match(regName)){
      this.ProductserveService.addpro(this.product).subscribe((ProData)=> this.ProductserveService.getProduct().subscribe((data)=>this.products=data),
      (error)=>{
        console.error(error);
      })
    }
    else{
      alert("please enter numeric value in id and price");
      alert("name field first letter should be capital letter ");
    }
  }
  }
  }
// id():boolean{
//   console.log("dsf");
//   var a=(document.getElementById("pid")as HTMLInputElement).value;
//   var b="/^[0-9]+$/";
//   if(a.match(b))
//   {
//     return true;
//   }
//   else{
//     alert("enter only numbers");
//     return false;
//   }
// }

 
 

