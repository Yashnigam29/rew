export class Product {
    id:number;
    proName:string;
    prodescription:string;
    price:number;
    ram:string;
    rom:string;
    battery:number;
    processor:number;
    length:number;
}
