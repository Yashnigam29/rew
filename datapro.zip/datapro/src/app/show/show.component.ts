import { Component, OnInit } from '@angular/core';
import { ProductserveService } from '../productserve.service'
import { Product } from '../product';
@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {

  product: Product = new Product();
  constructor(private ProductserveService: ProductserveService) { }

  ngOnInit() {
    this.ProductserveService.showProduct.subscribe(res => {
      this.product = res;
    })

  }
}

