import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom'
import Home from './home';
import Body from './body';
import jobs from './jobs';
import Message from './message';
import notification from './notification';


class Header extends Component {
  render() {
    return (
      <Router>
        <div>
          <div>
            <nav class="navbar navbar-default navbar-fixed-top">
              <div class="container-fluid">

                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="#">InBlink</a>
                </div>


                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                  <div>
                    <ul class="nav navbar-nav">
                      <li class="active"><Link to={'/'}>Home <span class="sr-only">(current)</span></Link></li>
                      <li><Link to={'/jobs'}>Jobs</Link></li>
                      <li><Link to={'/notification'}>Notify</Link></li>
                      <li><Link to={'/message'}>message</Link></li>
                    </ul>
                  </div>

                  <form class="navbar-form navbar-left">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Search" />
                    </div>
                    <button type="submit" class="btn btn-default">Submit</button>
                  </form>
                  <ul class="nav navbar-nav navbar-right">

                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">User <span class="caret"></span></a>
                      <ul class="dropdown-menu">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Profile</a></li>
                        <li><a href="#">Settings</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="#">Sign Out</a></li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>


          </div>
          <div class="container">
            <Switch>
              <Route exact path='/' component={Body} />
              <Route exact path='/jobs' component={jobs} />
              <Route exact path='/notification' component={notification} />
              <Route exact path='/message' component={Message} />


            </Switch>
          </div>
        </div>
      </Router>


    );

  }
}

export default Header;
