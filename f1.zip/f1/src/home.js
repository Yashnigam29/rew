import React, { Component } from 'react';
import logo from './logo.svg';

class Home extends Component {

  state = {
    count: 0
  };
  handleClick = () => {
    this.setState(({ count }) => ({
      count: count + 1
    }));
  };
   Prducts=[{id:1,name:"Rishu",location:"kolkata"},
   {id:2,name:"yash",location:"Banglore"},
   {id:3,name:"Rishab",location:"Mumabai"}];
 
  render() {
    return (
      
      <div className="row">
      <div className="data">
     
          <h4><span> <img src={logo} height="20px;"></img></span><u>Rishu Yadav</u></h4>
          <p>Software engineer at capgemini..he loves codeing...he loves codeing...he loves codeing..
            .he loves codeing...he loves codeing...he loves codeing...he loves codeing...</p><hr/>
            <img src={logo} height="250px;"></img>
          
            
           <hr/>
           {/* {this.Prducts[1].name}  */}
           
            <span>Like &nbsp;
                 {this.state.count}</span> &nbsp; &nbsp;<span>Comments {0}</span><br></br>
           
            <textarea rows="3"  cols="60" placeholder="comments..."></textarea><br/>
          
            <span class="glyphicon glyphicon-plus"></span>   <button class="glyphicon glyphicon-heart" onClick={this.handleClick}></button> <span class="glyphicon glyphicon-star"></span>  <span class="glyphicon glyphicon-envelop"></span>
            <span class="glyphicon glyphicon-share-alt"></span></div>
      </div> 
     
    );
  }
}


export default Home;
