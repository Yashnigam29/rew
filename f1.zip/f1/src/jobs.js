import React, { Component } from 'react';
import logo from './logo.svg';




class Jobs extends Component {

    render() {
        return (
            <div>
                <div class="col-md-3 data">
                    <img src={logo} width="70px;" className="img" />
                    <hr/>
                    <h3>Capgemini</h3>
                    <p><i>I gate Epip zone. Banglore whitefield</i></p>
                    <hr/>
                    <h6> 4 days ago</h6>
                </div>


            </div>
        );


    }


    //     render() {
    //         const  lists =  [{ id: 1, name: 'Harry potter', price: 200, img:{logo} },
    //         { id: 2, name: 'Avenger', price: 300, img: {logo}},
    //         { id: 3, name: 'Khalnayak', price: 150, img: { logo } }]

    //         return (

    //           <div className="movie">

    //             <ul style={{ listStyleType: "none" }}>
    //               {lists.map((item, index) => <li key={index}>

    //                 <div className="movie">

    //                   <img src={item.img} ></img>

    //                   <div className="text" >
    //                     <h4> {item.name} </h4>
    //                     <h5>Price:  <b> {item.price}/-</b></h5>
    //                   </div>
    //                 </div>

    //               </li>)}
    //             </ul>

    //           </div>
    //         );
    //   }
}


export default Jobs;
