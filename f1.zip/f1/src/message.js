import React, { Component } from 'react';
import logo from './logo.svg';




class Message extends Component {
 
  render() {
    return (
      
    <div>Message work
        </div>
     
    );
  }
}


export default Message;
