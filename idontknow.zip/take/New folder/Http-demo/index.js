var http=require("http");
// var {requestHandler}=require("./request-handler");
const app=require("./server");
var server=http.createServer(app);
server.listen(5000,(err)=>{
    if(err){
        console.log("couldnot start server");
        return;
    }
    console.log("server started in port 5000");
})