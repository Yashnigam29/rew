var fs=require("fs");
var path=require("path");
exports.requestHandler=(req,res)=>{
    res.setHeader("Content-type","text/html");
    var layout=getViewContent("layout.html");
    if(req.url=="/"){
       
        var body=getViewContent("index.html");
        // res.write("<h2>hello welcome to node webserver</h2>");
       var content= layout.replace("{{body-content}}",body);
        res.write(content);
        res.end();
    }
    else if(req.url=="/about"){
        var body=getViewContent("about.html");
        var content= layout.replace("{{body-content}}",body);
        res.write(content);
        // res.write("<h2>about page</h2>");
        res.end();
    }
    else if(req.url=="/contact"){
        var body=getViewContent("contact.html");
        var content= layout.replace("{{body-content}}",body);
        res.write(content);
        // res.write("<h2>contact page</h2>");
        res.end();

    }
    else if(req.url=="/register" && req.method=="GET"){
        var body=getViewContent("register.html");
        var content= layout.replace("{{body-content}}",body);
        res.write(content);
        res.end();
    }
    else if(req.url=="/register" && req.method=="POST"){
         var formData="";
         req.on("data",(chunk)=>{
             formData+=chunk;
         })
         req.on("end",()=>{
             res.write(formData);
             res.end();
         })
    }
    
}
function getViewContent(filename){

    var filePath=path.resolve(__dirname,"views",filename);
    var content=fs.readFileSync(filePath);
    return content.toString();
}