const express=require("express");
const bodyParser=require("body-parser");
const cookieParser=require("cookie-parser");
const session=require("express-session");
var Path=require("path");

var app=express();

// custom middleware
app.use("/about",(req,res,next)=>{
    req.author="yash nigam";
    req.verified=true;
    next();
})
app.use(express.static(Path.resolve(__dirname,"public")));
app.use(cookieParser("mysecretkey"));
app.use(session({name:"session",resave:true,saveUninitialized:false,
secret:"mysecretsessionkey"}))

app.get("/",test,test1,(req,res)=>{
    res.cookie("company","capgemini",{maxAge:60000,signed:true});
    res.cookie("place","bangalore");
    req.session.Department="consulting";
    req.session.salary=98000;
    res.header("Content-Type","text/html")
    .send(`<link rel="stylesheet" href="/public/mystyle.css"/>
    <h2 class="style1">home page</h2>` + req.message +req.a);
})
app.get("/about",(req,res)=>{
    var companyName=req.cookies.company || "nil";
    var place=req.cookies.place || "NIL";
    var dept=req.session.Department || "NIL";
    var sal=req.session.salary || 0;
    req.session.destroy();
    console.log(companyName);
    res.header("Content-Type","text/html")
    .send(`<h2>about page</h2> <p>company:${companyName}</p> <p>place:${place}</p> <p>depaty:${dept}</p>
    <p>sal:${sal}</p>`);
})
app.get("/contact",(req,res)=>{
    res.header("Content-Type","text/html")
    .send("<h2>contact page</h2>" + req.author);
})
module.exports=app;

function test(req,res,next){
    req.message="Hello all";
    next();
}

function test1(req,res,next){
    req.a=" good morning";
    next();
}