function sayHello(name,callback){
    setTimeout(()=>{
        callback( "Hello" +name);
        },3000);
}
console.log("calling sayhello()");
sayHello("yash",function(result){
       console.log(result);
})
console.log("completed");