var EventEmitter=require("events").EventEmitter;
var ee=new EventEmitter();

ee.on("ok",function(){
    console.log("ok event reiase");
})
ee.emit("ok");