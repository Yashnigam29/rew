var EventEmitter=require("events").EventEmitter;
var ee=new EventEmitter();
var timer;
ee.on("start",(startpos)=>{
    var i=startpos;
    console.log("starting");
    timer=setInterval(()=>{
        console.log(i);
        i++;
    },500);
});

ee.on("stop",()=>{
  console.log("stop timer");
  clearInterval(timer);
});
ee.emit("start",100);

setTimeout(()=>{
      ee.emit("stop");
    //   ee.emit("start",50);
},10000)