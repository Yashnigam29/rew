var buff=Buffer.from("Sample data");
console.log(buff.toString());
// console.log(buff);
var b=Buffer.alloc(20);
// b.write("this is the sample data");
// console.log(b.toString());
var noifbyteswritten=b.write("this is sample");
console.log("bytes written:" +noifbyteswritten);
console.log(b.toString());