var fs=require("fs");
var path=require("path");
exports.writeContent=(filename,content)=>{
    
    var filePath=path.resolve(__dirname ,"myfiles" , filename);
    fs.open(filePath,"w",(err,fd)=>{

        if(err){
            console.log("failed to open files");
            return;
        }
        fs.write(fd,Buffer.from(content),(err,noOfBytes,buff)=>{
            if(err){
                console.log("failed to write files");
                return;
            }
            console.log("succesfully writen the content");
            fs.close(fd,(err)=>{
                if(err)
                {
                    console.log("error in closing fiel");
                    return;
                }
                console.log("file closed");
            })
        })
    })
}

exports.readContent=(filename,callback)=>{
    var filePath=path.resolve(__dirname ,"myfiles" ,filename);
    fs.open(filePath,"r",(err,fd)=>{

        if(err){
            console.log("failed to open files");
            return;
        }
      var buffer=Buffer.alloc(20);
      fs.read(fd,buffer,0,20,0,(err,bytesRead,buff)=>{
          if(err){
              console.log("failed to read");
              return;
            }
                callback(buff.toString());
     fs.close(fd,(err)=>{
                console.log("file closed");
            })
      })
});
}

exports.writeContentSync=(filename,content)=>{
    var filePath=path.resolve(__dirname,"myfiles",filename);
    var fd=fs.openSync(filePath,"w")
    if(!fd){
        console.log("failed to open file");
        return;
    }
    
    var bytes=fs.writeSync(fd,Buffer.from(content));
    console.log("file written success");
    fs.closeSync(fd);
}
exports.readContentSync=(filename)=>{
    var filePath=path.resolve(__dirname,"myfiles",filename);
    var fd=fs.openSync(filePath,"r")
    if(!fd){
        console.log("failed to open file");
        return;
    }
    var buffer=Buffer.alloc(20);
    var bytes=fs.readSync(fd,buffer,0,20,0);
    console.log(buffer.toString());
    fs.closeSync(fd);
}
exports.writeFileContent=(filename,content)=>{
    var filePath=path.resolve(__dirname,"myfiles",filename);
    fs.writeFile(filePath,content,(err)=>{
        if(err){
            console.log("failed to writing files");
            return;
        }
        console.log("succesfully writen into file");
    })
}
exports.readFileContent=(filename)=>{
    var filePath=path.resolve(__dirname,"myfiles",filename);
    fs.readFile(filePath,{encoding:"utf-8"},(err,data)=>{
        if(err){
            console.log("failed to reading files");
            return;
        }
        console.log(data);
    })
}