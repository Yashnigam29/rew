// console.log(__dirname);
// console.log(__filename);
var fs=require("fs");
 var path=require("path");
// var filePath=path.resolve(__dirname +"myfiles" + "akbns.txt");
// console.log(filePath);
// var {writeContent,readContent,readContentSync,writeContentSync,writeFileContent
// ,readFileContent}=require("./file-handler");
var {readFromFileStream,writeToFileStream}=require("./stream-demo");
var data="hello how are u yash123";
var filename="greet3.txt";

writeToFileStream(filename,data);
readFromFileStream(filename);

// writeContent(filename,data);
// readContent(filename,function(result){
//     console.log(result);
// });
// writeContentSync(filename,data);
// readContentSync(filename);
// writeFileContent(filename,data);
// readFileContent(filename);

// var filePath=path.resolve(__dirname ,"myfiles" , filename);
// fs.stat(filePath,(err,stats)=>{
//     console.log(stats);
// })
// fs.watchFile(filePath,(current,prev)=>{
//   console.log(prev.size+ "        " + current.size);
// })
