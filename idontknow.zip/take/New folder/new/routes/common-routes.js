const express=require("express");
const User=require("../models/user-model");
var router=express.Router();

router.get("/", (req,res)=>{
    res.header("Content-Type","text/html").render("index");
});
router.get("/about", (req,res)=>{
    res.header("Content-Type","text/html").send("about");
})
router.get("/contact",(req,res)=>{
    res.header("Content-Type","text/html").send("contact");
})
router.get("/add",(req,res)=>{
    res.header("Content-Type","text/html").render("add");

    
})
    //POST /register
router.post("/register",(req,res)=>{
    var formData=req.body;
    var user=new User({
        firstName:formData.name,
        email:formdata.emai,
        password:formData.password
    })

    user.save(function(err){
        if(err){
            res.send("erroor in saving data");
        }
        res.send("success saved");

//     console.log(formData);
//     res.send(formData);
 })
})
module.exports=router;