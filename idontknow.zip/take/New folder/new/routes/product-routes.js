const express=require("express");
var router=express.Router();

var products=[
    {id:1,name:"Apple",quantity:10,price:120},
    {id:2,name:"orange",quantity:20,price:50},
    {id:3,name:"grape",quantity:15,price:100},
];
var employee=[
    {id:1,name:"Apple",quantity:10,price:120},
    {id:2,name:"orange",quantity:20,price:50},
    {id:3,name:"grape",quantity:15,price:100},
]
router.get("/list",(req,res)=>{
    var model={
         caption:"product list",
         items:products
    };
    res.header("Content-Type","text/html").render("product-list",model);
})

router.get("/add",(req,res)=>{
    res.header("Content-Type","text/html").send("adding product");
})
module.exports=router;