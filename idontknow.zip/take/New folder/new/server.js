const express=require("express");
const bodyParser=require("body-parser");
const cookieParser=require("cookie-parser");
const session=require("express-session");
var Path=require("path");
const commonRoutes=require("./routes/common-routes");
const productRoutes=require("./routes/product-routes");
var app=express();

//set the view engine
app.set("views","views");
app.set("view engine","pug");

app.use(express.static(Path.resolve(__dirname,"public")));
app.use(cookieParser("mysecretkey"));
app.use(session({name:"session",resave:true,saveUninitialized:false,
secret:"mysecretsessionkey"}))

app.use("/",commonRoutes);
 app.use("/products",productRoutes);

module.exports=app;

