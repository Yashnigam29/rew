function saygoodmorning(name){
    return `Good Morning ${name}`;
}
function saygoodevening(name){
    return `Good evening ${name}`;
}
function saygoodafternoon(name){
    return `Good afternoon ${name}`;
}
module.exports={
    saygoodmorning,
    saygoodevening,
    getafternoon:saygoodafternoon
}