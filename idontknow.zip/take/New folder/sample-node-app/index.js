var Person=require("./person");

var Calculator=require("./calculator");
var {getafternoon}=require("./greeting");

var a=5,b=3;
var res=Calculator.multiply(a,b);
console.log(`Product is ${res}`);

var person=new Person();
person.firstName="yash";
person.lastName="nigam";
var fullname=person.getFullName();
var greeting=getafternoon(fullname);
console.log(greeting);