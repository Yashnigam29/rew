class Person{
    constructor(){
        this.firstName="";
        this.lastName="";
    }
    getFullName(){
        return `${this.firstName} ${this.lastName}`;
    }
}

module.exports=Person;