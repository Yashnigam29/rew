import React from 'react';

import ReactDOM from 'react-dom';

class Parent extends React.Component{
    render(){
      
        const buttons=React.Children.
		map(this.props.children,child=>(
       	<i>
		{child}
	              </i>
         	));
        return(
            <div>count: {React.Children.count(this.props.children)}
                  {React.Children.only(this.props.children)}
            	{buttons}
                </div>

        );
    }
}
export default Parent;