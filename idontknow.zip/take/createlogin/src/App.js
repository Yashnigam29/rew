import React from 'react';
// y
// import React from 'react';import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';

class App extends React.Component {

  constructor(){
    super();
    this.state={
      username:"",
      password: "",
      check1 : true
    }
  }

handleChange=(event)=>{
this.setState({
username : event.target.value,

});

}
function2=(event)=>{
  this.setState({
  password:event.target.value
  });
}

  handelclick=(event)=>{
    // this.flag!=this.flag;
    event.preventDefault();
    console.log("g",event.target.value)
    
         this.setState({
    
          check1: false
         });
  }
  function1=(event)=>{
    event.preventDefault();
    console.log("sdlhfa");
    this.setState({
      check1 : true
    })
  }

  render(){
     if(this.state.check1){
    return (
      <div >
        <label>Username</label>
        <input type ="text" value={this.state.username} onChange={this.handleChange} />
        <label>password</label>
        <input type ="password" value ={this.state.password} onChange={this.function2} />
        <input type="submit" value="submit" onClick={this.handelclick}/><br/>
        {this.setState.username}
      </div>
    );
  }
  else{
    
    return(
      <div>
          <label><h2>Login page</h2></label>
          welcome {this.state.username}
          <input type="submit" value="signout" onClick={this.function1}/>
        </div>
    )
  }
  }
}

export default App;
