import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ReactDOM from 'react-dom';

var createReactClass = require('create-react-class');
//console.log(createReactClass);
var App = createReactClass({
  render: function() {
    const Welcome = React.createElement('h1','null','welcome to capgemini');
    return <div>{Welcome}</div>;
  }
});
export default App;
