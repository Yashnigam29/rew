import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import App from './App';
import user from './user.png';
import guest from './guest.jpg';
// import * as serviceWorker from './serviceWorker';

// ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
// serviceWorker.unregister();
class Demo extends React.Component{
  render(){
  
    const flag=this.props.img1;
    if(flag){
        return (
            <div className="Demo">
                <img src={user} />
                <h1> this is user</h1>
              </div>
           
          );
    }
    else{
        return (
            <div className="Demo">
                <img src={guest} />

                <h1> this is guest</h1>
              </div>
            
          );
    }


   }
}
ReactDOM.render(<Demo img1={false}/>,document.getElementById('root'));