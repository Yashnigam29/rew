import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import App from './App';
// import * as serviceWorker from './serviceWorker';
import Movielist from './movielist';
import ima from './pubg.jpg';
// import { ReactComponent } from '*.svg';
var product={movieName: "Avengers",price:"400",im:ima}

ReactDOM.render(<Movielist prod={product}/>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
// serviceWorker.unregister();
