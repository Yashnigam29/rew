import React from 'react';

import ReactDOM from 'react-dom';

class Movielist extends React.Component{
    render(){
        return(
            <div>
                <h1>{this.props.prod.movieName}</h1><br/>
                <h2>{this.props.prod.price}</h2><br/>
                <img src={this.props.prod.im}/>
                </div>
        )
    }
}
export default Movielist;