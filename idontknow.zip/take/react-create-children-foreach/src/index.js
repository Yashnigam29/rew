import React from 'react';

import ReactDOM from 'react-dom';

import Parent from './Parent';


class App extends React.Component {
  render() {
return(
   <div>
	<Parent>
		<h1>i am child</h1>
		<h1>i am child</h1>
	</Parent>
   </div>
	);
  }
}
ReactDOM.render(<App />, document.getElementById('root'));

/*
first demo
<Parent/>	
	<Parent></Parent> 
	<Parent>this is parent 1</Parent>
<Parent>
		<p>item 1</p>
		<p>item 2</p>
		<p>item 3</p>
	</Parent>
=========================
second
change React.children.only() in Parent component

so it  works if we keep only one parent tag in App component

	<Parent>
		<h1>i am only child</h1>
		<h1>i am only child</h1>
	</Parent>
this will throw 
React.Children.only expected to receive a single React element child. error.

error solved by removing one child ie., <h1> tag



*/
