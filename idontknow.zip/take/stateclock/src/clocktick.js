import React from 'react';

import ReactDOM from 'react-dom';

class Clocktick extends React.Component{
     constructor(){
         super();
         this.state={company:["Capgemini"]};
     }
    render(){
        setTimeout(()=>{
            const items = this.state.company;
             console.log(items);
            items[0]='igate';
             console.log(items[0]);
//this.state.country=items; 
            this.setState({company:items});
        },1000)

        return(
            <div>
			<p>company are...</p>
				<ul>
				<li>{this.state.company[0]}</li>
				</ul>
		</div>
        )
    }
}
export default Clocktick;