import { Component, OnInit } from '@angular/core';
import { ProductserveService} from '../productserve.service'
import { Product } from '../product';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css'],
})
export class AddComponent implements OnInit {
  products: Product[]=[];
  product:Product=new Product();
  constructor(private ProductserveService:ProductserveService) { }

  ngOnInit() {
  }
add():void{
    this.ProductserveService.addpro(this.product).subscribe((ProData)=> this.ProductserveService.getProduct().subscribe((data)=>this.products=data),
    (error)=>{
      console.error(error);
    })
  }
  }
// id():boolean{
//   console.log("dsf");
//   var a=(document.getElementById("pid")as HTMLInputElement).value;
//   var b="/^[0-9]+$/";
//   if(a.match(b))
//   {
//     return true;
//   }
//   else{
//     alert("enter only numbers");
//     return false;
//   }
// }

 
 

