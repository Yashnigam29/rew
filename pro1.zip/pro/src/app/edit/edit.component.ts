import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Product } from '../product';
import { ProductserveService } from '../productserve.service'

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  product: Product=new Product();
  products:Product[]=[];


  constructor(private ProductserveService: ProductserveService) {

  }

  ngOnInit() {
    this.ProductserveService.showProduct.subscribe(res => {
      this.product = res;
    })
  }
  edit(): void {
    //   console.log("update button entered");
    //   Object.assign(this.product,this.ProductserveService.getProduct().subscribe((data)=>this.products=data));

      this.ProductserveService.updatepro(this.product).subscribe((ProData)=> this.ProductserveService.getProduct().subscribe((data)=>this.products=data),
      (error)=>{
        console.error(error);
      })
  }
}
